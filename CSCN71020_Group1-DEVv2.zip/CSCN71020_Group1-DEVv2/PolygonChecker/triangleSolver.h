#pragma once
char* analyzeTriangle(double side1, double side2, double side3);
double calculateAngle(double a, double b, double c);